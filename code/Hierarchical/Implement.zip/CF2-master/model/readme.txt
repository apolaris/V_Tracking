Download the VGG-Net-19 model using the link 
http://www.vlfeat.org/matconvnet/models/imagenet-vgg-verydeep-19.mat
