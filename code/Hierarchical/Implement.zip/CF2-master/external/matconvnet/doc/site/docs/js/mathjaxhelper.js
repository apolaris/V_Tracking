/*
#if false
Prevent Unity to try compiling this js
*/
MathJax.Hub.Config({
	"tex2jax": { inlineMath: [ [ '$', '$' ] ] }
	});
/*
#endif
*/